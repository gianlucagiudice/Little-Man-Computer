# Little Man Computer

Gianluca Giudice 830694
Implementation of "little man computer" by Gianluca Giudice in Common Lisp.

## File structure

- **lmc** The whole LMC implementation

## Notes

- The function "lmc-run" contains *(compile 'execution-loop)* in order to optimize tail recursion and avoid stack overflow

## Version
Clisp 2.49.92 (2018-02-18) on Ubuntu 18.10

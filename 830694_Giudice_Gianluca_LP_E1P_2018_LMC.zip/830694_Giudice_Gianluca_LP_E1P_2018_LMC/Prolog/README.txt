# Little Man Computer

Gianluca Giudice 830694
Implementation of "little man computer" by Gianluca Giudice in Prolog.

## File structure

- **lmc** Entry point for the program
- **compiler** Compile assembly file
- **executer** Execute the content of the memory


## Version
SWI-Prolog 7.6.4 on Ubuntu 18.10
